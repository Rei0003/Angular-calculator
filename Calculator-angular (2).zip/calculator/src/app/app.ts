import { Component, signal } from '@angular/core';
import { CalcButton } from './calc-button/calc-button';

interface Key {
  label: string;
  operator: boolean;
}

@Component({
  selector: 'app-root',
  imports: [CalcButton],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly display = signal('');

  protected readonly keys: Key[] = [
    { label: '+', operator: true },
    { label: '7', operator: false },
    { label: '8', operator: false },
    { label: '9', operator: false },
    { label: '-', operator: true },
    { label: '4', operator: false },
    { label: '5', operator: false },
    { label: '6', operator: false },
    { label: '*', operator: true },
    { label: '1', operator: false },
    { label: '2', operator: false },
    { label: '3', operator: false },
    { label: '/', operator: true },
    { label: '0', operator: false },
    { label: '.', operator: false }
  ];

  protected append(input: string): void {
    this.display.update(value => value + input);
  }

  protected clear(): void {
    this.display.set('');
  }

  protected calculate(): void {
    try {
      this.display.set(String(new Function(`return (${this.display()})`)()));
    } catch {
      this.display.set('Error');
    }
  }
}
