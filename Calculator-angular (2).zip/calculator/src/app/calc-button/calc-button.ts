import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-calc-button',
  templateUrl: './calc-button.html',
  styleUrl: './calc-button.css'
})
export class CalcButton {
  readonly label = input.required<string>();
  readonly operator = input(false);
  readonly pressed = output<string>();
}
